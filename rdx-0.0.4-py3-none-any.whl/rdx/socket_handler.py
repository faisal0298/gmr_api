import socketio
from socketio.exceptions import *
import datetime
import time
import copy
import json


class SocketHandler:
    sio = socketio.Client()

    def __init__(self, service_id, parent_ids=[]):
        """
        The constructor of socket handler for rdx application.

        Parameters:
            service_id (str): An id to be assigned to given usecase.
            parent_ids (list): The list of parent service ids.

        Returns:
            None
        """
        self.rooms = []
        self.service_id = service_id
        self.parent_ids = parent_ids
        self.params = {}

    def acknowledgement(self, id):
        self.sio.emit("acknowledgement", {"id": id})

    def fetch_info(self):
        """
        The function is used to fetch the details related to sources
        """
        self.sio.emit("info", self.service_id)

    def send_status(self, status):
        self.sio.emit(
            "out",
            {
                "source": self.service_id,
                "destination": "camera",
                "data": {"type": "status", "value": status},
            },
        )

    def send_metadata(self, data):
        """
        The function is used to send the metadata to socket server
        """
        self.sio.emit("metadata", {"data": data, "room": self.service_id})

    def run(self, ip="localhost", port=5000, *args, **kwargs):
        """
        The function to connect to the rdx server and run the socket handler.

        Parameters:
            ip (str): An ip of the device running rdx application.
            port (int): A port number of server running the rdx application.

        Returns:
            None
        """
        serverUrl = "http://{}:{}".format(ip, port)
        self.configurations(*args, **kwargs)

        while True:
            try:
                self.sio.connect(serverUrl)
                break
            except (ConnectionError, ConnectionRefusedError) as e:
                print("Connection error. Retrying ...!")
                time.sleep(10)

    def configurations(self, *args, **kwargs):
        @self.sio.event
        def connect():
            if not len(self.rooms):
                self.sio.emit("join", {"room": self.service_id})

                if len(self.parent_ids):
                    self.sio.emit(
                        "rooms",
                        {"parent_ids": self.parent_ids, "usecase_id": self.service_id},
                    )
                    self.sio.emit(
                        "out",
                        {
                            "source": self.service_id,
                            "destination": "camera",
                            "data": {"type": "status", "value": True},
                        },
                    )

        @self.sio.on("stop")
        def disconnect_from_server(data):
            self.acknowledgement(data["id"])
            if data["data"] == self.service_id:
                for room in self.rooms:
                    self.sio.emit("leave", {"room": room})
                self.sio.emit("leave", {"room": self.service_id})
                self.sio.emit(
                    "out",
                    {
                        "source": self.service_id,
                        "destination": "camera",
                        "data": {"type": "status", "value": False},
                    },
                )
                self.sio.disconnect()

    def on_disconnect(self, func):
        @self.sio.on("disconnect")
        def wrap(*args, **kwargs):
            self.sio.emit(
                "out",
                {
                    "source": self.service_id,
                    "destination": "camera",
                    "data": {"type": "status", "value": False},
                },
            )
            return func(*args, **kwargs)

        return wrap

    def add_camera_handler(self, func):
        @self.sio.on("join_room")
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            if data["room"] not in self.rooms:
                self.sio.emit("join", {"room": data["room"]})
                self.rooms.append(data["room"])
            else:
                return None
            dictionary = {
                "camera_id": data["camera_id"],
                "camera_name": data["camera_name"],
                "location": data["location"],
            }
            return func(dictionary, *args, **kwargs)

        return wrap

    def remove_camera_handler(self, func):
        @self.sio.on("leave_room")
        def wrap(room, *args, **kwargs):
            self.acknowledgement(room["id"])
            if room["data"] in self.rooms:
                self.sio.emit("leave", {"room": room["data"]})
                self.rooms.remove(room["data"])

            dictionary = {"camera_id": room["data"].split("_")[1]}
            return func(dictionary, *args, **kwargs)

        return wrap

    def usecase_params_handler(self, func):
        @self.sio.on("params")
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            params = copy.deepcopy(data["data"])
            camera_id = params.pop("camera_id")
            del params["service_id"]
            self.params[camera_id] = params
            return func(data["data"], *args, **kwargs)

        return wrap

    def metadata(self, func):
        @self.sio.on("message")
        def wrap(*args, **kwargs):
            return func(*args, **kwargs)

        return wrap

    def start(self, func):
        @self.sio.on("start")
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            return func(data["data"], *args, **kwargs)

        return wrap

    def restart(self, func):
        @self.sio.on("restart")
        def wrap(*args, **kwargs):
            return func(*args, **kwargs)

        return wrap

    def image(self, func):
        @self.sio.on("image")
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            return func(data["data"], *args, **kwargs)

        return wrap

    def delete_image_handler(self, func):
        @self.sio.on("delete")
        def wrap(data, *args, **kwargs):
            self.acknowledgement(data["id"])
            return func(data["data"], *args, **kwargs)

        return wrap

    def fetch_data(self, func):
        @self.sio.on("subscribe")
        def wrap(data, *args, **kwargs):
            # self.acknowledgement(data["id"])
            return func(data, *args, **kwargs)

        return wrap

    def send_data(self, destination="base", type="save_alert", **data):
        """
        The function is used to send the data from usecase to socket server

        Parameters:
            destination (str): service name to which data needs to be sent.
            data (dict): data to be sent to destination service.

        Returns:
            None
        """
        data.update({"type": type})
        self.sio.emit(
            "publish",
            {"source": self.service_id, "destination": destination, "data": data},
        )
